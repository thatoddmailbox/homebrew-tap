class Roamer < Formula
    desc "Tool that makes handling database migrations easy"
    homepage "https://github.com/thatoddmailbox/roamer"
    url "https://github.com/thatoddmailbox/roamer/archive/v0.1.1.tar.gz"
    sha256 "88ceeec110b3918ebc947b9aa6a4a33b96bcd77baeea952117be5067296d4126"
  
    depends_on "go" => :build
  
    def install
      system "go", "build", *std_go_args, "./cli/"
    end
  
    test do
      system "#{bin}/roamer", "-version"
    end
  end
  