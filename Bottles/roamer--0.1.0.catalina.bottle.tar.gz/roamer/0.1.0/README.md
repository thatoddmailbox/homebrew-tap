# roamer
`roamer` is a tool that makes handling database migrations easy. It's mainly inspired by [alembic](https://alembic.sqlalchemy.org) and [golang-migrate](https://github.com/golang-migrate/migrate).

It's available as a command-line tool that can be used with any programming language; however, if you're using Go, you can also embed roamer directly into your program.

_Documentation coming soon! While the command-line interface is mostly stable, the Go API should not be considered stable quite yet!_